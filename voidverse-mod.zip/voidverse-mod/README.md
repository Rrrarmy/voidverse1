# Voidverse (Fabric, Minecraft Java 26.2)

Commands:
  /rocket [destination]   rocket build karta hai, andar ka laal button dabao -> launch
  /voidverse <destination>  seedha teleport (testing)

Destinations: overworld, underverse, earth, moon, mercury, venus, mars, jupiter, saturn, uranus, neptune

Build: fabric-example-mod se gradle wrapper (gradlew, gradle/) copy karo, phir ./gradlew build
Jar: build/libs/voidverse-1.0.0.jar
