package com.voidverse;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Har tick: Space me gravity badlo, aur void / height limit cross karne par dimension change karo. */
public final class Physics {
	private static final double BASE_G = 0.08;
	private static final double BASE_SAFE_FALL = 3.0;
	private static final double DEEP_SPACE_G = 0.02;

	private static final Set<UUID> modified = new HashSet<>();
	private static int tickCounter = 0;

	public static void tick(MinecraftServer server) {
		tickCounter++;
		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			ResourceKey<Level> dim = p.level().dimension();

			if (dim.equals(Dims.SPACE)) {
				space(p);
				continue;
			}

			// Space se bahar aate hi normal gravity wapas
			if (modified.remove(p.getUUID())) {
				setBase(p, Attributes.GRAVITY, BASE_G);
				setBase(p, Attributes.SAFE_FALL_DISTANCE, BASE_SAFE_FALL);
				p.removeEffect(MobEffects.NIGHT_VISION);
			}

			if (Rockets.isLaunching(p.getUUID())) continue;

			if (dim.equals(Level.OVERWORLD) && p.getY() < -90) {
				// Overworld ke void me gire -> Underverse
				Travel.to(p, "underverse");
			} else if ((dim.equals(Level.OVERWORLD) || dim.equals(Dims.UNDERVERSE)) && p.getY() > 330) {
				// Height limit ke upar -> Universe
				Travel.to(p, "earth");
			}
		}
	}

	private static void space(ServerPlayer p) {
		modified.add(p.getUUID());
		double x = p.getX(), y = p.getY(), z = p.getZ();

		Planets.Planet nearest = null;
		double best = Double.MAX_VALUE;
		for (Planets.Planet pl : Planets.ALL) {
			double e = pl.edgeDistance(x, y, z);
			if (e < best) {
				best = e;
				nearest = pl;
			}
		}

		double g = DEEP_SPACE_G;
		if (nearest != null && best <= Math.max(nearest.radius(), 24)) {
			g = nearest.gravity();
			if (nearest.kind() == Planets.Kind.SUN && best < 6) {
				p.setRemainingFireTicks(100); // Sun ke paas jalna padega
			}
		}
		setBase(p, Attributes.GRAVITY, g);
		setBase(p, Attributes.SAFE_FALL_DISTANCE, BASE_SAFE_FALL * Math.max(1.0, BASE_G / g));

		if (tickCounter % 40 == 0) {
			p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
		}

		if (y < -10 && !Rockets.isLaunching(p.getUUID())) {
			Travel.to(p, "earth"); // Space se neeche gire to Earth par wapas
		}
	}

	private static void setBase(ServerPlayer p, Holder<Attribute> attr, double value) {
		AttributeInstance inst = p.getAttribute(attr);
		if (inst != null && Math.abs(inst.getBaseValue() - value) > 1e-9) {
			inst.setBaseValue(value);
		}
	}

	private Physics() {
	}
}
