package com.voidverse;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;

public class VoidverseMod implements ModInitializer {

	@Override
	public void onInitialize() {
		// Space dimension ke naye chunks me planets bana do
		ServerChunkEvents.CHUNK_LOAD.register((level, chunk, generated) -> {
			if (generated && level.dimension().equals(Dims.SPACE)) {
				Planets.fillChunk(chunk);
			}
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			Physics.tick(server);
			Rockets.tick(server);
		});

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
			Rockets.registerCommands(dispatcher));

		UseBlockCallback.EVENT.register(Rockets::onUseBlock);
	}
}
