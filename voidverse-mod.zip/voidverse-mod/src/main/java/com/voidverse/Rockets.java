package com.voidverse;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * /rocket [destination]  -> block ka rocket build karta hai, player andar.
 * Andar ka laal (crimson) button dabao -> countdown -> launch -> destination.
 */
public final class Rockets {
	public static final List<String> DESTS = List.of(
		"overworld", "underverse", "earth", "moon", "mercury", "venus", "mars", "jupiter", "saturn", "uranus", "neptune");

	private static final int FLAGS = 2 | 16;
	private static final int COUNTDOWN = 100; // 5 sec
	private static final int ASCENT = 60;     // 3 sec

	private static final Map<String, String> programmed = new HashMap<>();
	private static final List<Launch> launches = new ArrayList<>();

	private static final class Launch {
		final UUID player;
		final ResourceKey<Level> dim;
		final BlockPos base;
		final String dest;
		int t = 0;

		Launch(UUID player, ResourceKey<Level> dim, BlockPos base, String dest) {
			this.player = player;
			this.dim = dim;
			this.base = base;
			this.dest = dest;
		}
	}

	public static boolean isLaunching(UUID id) {
		for (Launch l : launches) {
			if (l.player.equals(id)) return true;
		}
		return false;
	}

	// ---------------- commands ----------------
	public static void registerCommands(CommandDispatcher<CommandSourceStack> d) {
		d.register(Commands.literal("rocket")
			.executes(c -> spawn(c.getSource(), null))
			.then(Commands.argument("destination", StringArgumentType.word())
				.suggests((c, b) -> SharedSuggestionProvider.suggest(DESTS, b))
				.executes(c -> spawn(c.getSource(), StringArgumentType.getString(c, "destination")))));

		// testing / shortcut: seedha teleport
		d.register(Commands.literal("voidverse")
			.then(Commands.argument("destination", StringArgumentType.word())
				.suggests((c, b) -> SharedSuggestionProvider.suggest(DESTS, b))
				.executes(c -> {
					ServerPlayer p = c.getSource().getPlayerOrException();
					String dest = StringArgumentType.getString(c, "destination").toLowerCase(Locale.ROOT);
					if (!DESTS.contains(dest) || !Travel.to(p, dest)) {
						c.getSource().sendFailure(Component.literal("Unknown destination: " + dest));
						return 0;
					}
					return 1;
				})));
	}

	private static int spawn(CommandSourceStack src, String destArg) throws CommandSyntaxException {
		ServerPlayer p = src.getPlayerOrException();
		ServerLevel lv = (ServerLevel) p.level();
		String def = lv.dimension().equals(Dims.SPACE) ? "overworld" : "earth";
		String dest = destArg == null ? def : destArg.toLowerCase(Locale.ROOT);
		if (!DESTS.contains(dest)) {
			src.sendFailure(Component.literal("Unknown destination: " + dest));
			return 0;
		}
		BlockPos c = p.blockPosition();
		build(lv, c);
		programmed.put(key(lv, c), dest);
		p.teleportTo(lv, c.getX() + 0.5, c.getY(), c.getZ() + 0.5, Set.of(), p.getYRot(), p.getXRot(), false);
		src.sendSuccess(() -> Component.literal("Rocket ready! Destination: " + dest
			+ ". Andar ka laal button dabao."), false);
		return 1;
	}

	private static String key(ServerLevel lv, BlockPos base) {
		return lv.dimension() + "|" + base.asLong();
	}

	// ---------------- button press ----------------
	public static InteractionResult onUseBlock(Player player, Level world, InteractionHand hand, BlockHitResult hit) {
		if (hand != InteractionHand.MAIN_HAND
			|| !(world instanceof ServerLevel lv)
			|| !(player instanceof ServerPlayer sp)) {
			return InteractionResult.PASS;
		}
		BlockPos btn = hit.getBlockPos();
		if (!lv.getBlockState(btn).is(Blocks.CRIMSON_BUTTON)) return InteractionResult.PASS;

		BlockPos base = btn.offset(0, -1, 1);
		if (!lv.getBlockState(base.above(3)).is(Blocks.SEA_LANTERN)) return InteractionResult.PASS; // hamara rocket nahi
		if (isLaunching(sp.getUUID())) return InteractionResult.SUCCESS;

		String dest = programmed.getOrDefault(key(lv, base),
			lv.dimension().equals(Dims.SPACE) ? "overworld" : "earth");
		launches.add(new Launch(sp.getUUID(), lv.dimension(), base, dest));
		sp.displayClientMessage(Component.literal("Launch sequence start! Destination: " + dest), false);
		return InteractionResult.SUCCESS;
	}

	// ---------------- launch ticking ----------------
	public static void tick(MinecraftServer server) {
		Iterator<Launch> it = launches.iterator();
		while (it.hasNext()) {
			Launch l = it.next();
			ServerPlayer p = server.getPlayerList().getPlayer(l.player);
			ServerLevel lv = server.getLevel(l.dim);
			if (p == null || lv == null || !p.isAlive()) {
				it.remove();
				continue;
			}
			l.t++;
			double bx = l.base.getX() + 0.5, by = l.base.getY(), bz = l.base.getZ() + 0.5;

			if (l.t <= COUNTDOWN) {
				if (!p.level().dimension().equals(l.dim) || p.distanceToSqr(bx, by, bz) > 36.0) {
					p.displayClientMessage(Component.literal("Launch abort - rocket se bahar nikal gaye."), true);
					it.remove();
					continue;
				}
				if (l.t % 20 == 0) {
					int sec = (COUNTDOWN - l.t) / 20;
					p.displayClientMessage(Component.literal(sec > 0 ? "Launch in " + sec : "Ignition!"), true);
				}
				lv.sendParticles(ParticleTypes.LARGE_SMOKE, bx, by - 0.5, bz, 4, 1.5, 0.1, 1.5, 0.02);
			} else if (l.t <= COUNTDOWN + ASCENT) {
				if (l.t == COUNTDOWN + 1) {
					clearRocket(lv, l.base);
					lv.playSound((Player) null, bx, by, bz, SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 3.0f, 0.6f);
				}
				p.setDeltaMovement(0.0, 1.3, 0.0);
				p.hurtMarked = true;
				p.resetFallDistance();
				lv.sendParticles(ParticleTypes.FLAME, p.getX(), p.getY() - 0.5, p.getZ(), 12, 0.3, 0.2, 0.3, 0.05);
				lv.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() - 1.0, p.getZ(), 6, 0.4, 0.3, 0.4, 0.02);
			} else {
				it.remove();
				if (Travel.to(p, l.dest)) {
					p.displayClientMessage(Component.literal("Welcome to " + l.dest + "!"), false);
				} else {
					p.displayClientMessage(Component.literal("Travel failed: " + l.dest), false);
				}
			}
		}
	}

	// ---------------- rocket structure ----------------
	private static void set(ServerLevel lv, int x, int y, int z, BlockState st) {
		lv.setBlock(new BlockPos(x, y, z), st, FLAGS);
	}

	private static BlockState b(net.minecraft.world.level.block.Block block) {
		return block.defaultBlockState();
	}

	public static void build(ServerLevel lv, BlockPos c) {
		int cx = c.getX(), by = c.getY(), cz = c.getZ();

		// pehle jagah saaf karo
		for (int dx = -3; dx <= 3; dx++) {
			for (int dz = -3; dz <= 3; dz++) {
				for (int y = by; y <= by + 11; y++) {
					set(lv, cx + dx, y, cz + dz, b(Blocks.AIR));
				}
				set(lv, cx + dx, by - 1, cz + dz, b(Blocks.GRAY_CONCRETE)); // launch pad 7x7
			}
		}

		// cabin: 5x5 deewar, andar 3x3 khali
		for (int y = by; y <= by + 2; y++) {
			for (int dx = -2; dx <= 2; dx++) {
				for (int dz = -2; dz <= 2; dz++) {
					boolean wall = Math.abs(dx) == 2 || Math.abs(dz) == 2;
					if (!wall) continue;
					boolean door = dx == 0 && dz == 2 && y <= by + 1;
					boolean window = y == by + 1 && Math.abs(dx) == 2 && dz == 0;
					if (door) continue;
					set(lv, cx + dx, y, cz + dz, window ? b(Blocks.GLASS) : b(Blocks.QUARTZ_BLOCK));
				}
			}
		}

		// chhat (5x5) + andar light
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				set(lv, cx + dx, by + 3, cz + dz, b(Blocks.QUARTZ_BLOCK));
			}
		}
		set(lv, cx, by + 3, cz, b(Blocks.SEA_LANTERN));

		// upar ka body + nose cone
		for (int y = by + 4; y <= by + 6; y++) {
			for (int dx = -1; dx <= 1; dx++) {
				for (int dz = -1; dz <= 1; dz++) {
					set(lv, cx + dx, y, cz + dz, b(Blocks.WHITE_CONCRETE));
				}
			}
		}
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				set(lv, cx + dx, by + 7, cz + dz, b(Blocks.RED_CONCRETE));
			}
		}
		set(lv, cx, by + 8, cz, b(Blocks.RED_CONCRETE));
		set(lv, cx, by + 9, cz, b(Blocks.RED_CONCRETE));
		set(lv, cx, by + 10, cz, b(Blocks.END_ROD));

		// fins
		for (int y = by; y <= by + 2; y++) {
			set(lv, cx + 3, y, cz, b(Blocks.RED_CONCRETE));
			set(lv, cx - 3, y, cz, b(Blocks.RED_CONCRETE));
			set(lv, cx, y, cz - 3, b(Blocks.RED_CONCRETE));
		}

		// launch button (andar, uttar deewar par, south ki taraf face)
		BlockState button = b(Blocks.CRIMSON_BUTTON)
			.setValue(BlockStateProperties.ATTACH_FACE, AttachFace.WALL)
			.setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
		set(lv, cx, by + 1, cz - 1, button);
	}

	private static void clearRocket(ServerLevel lv, BlockPos c) {
		for (int dx = -3; dx <= 3; dx++) {
			for (int dz = -3; dz <= 3; dz++) {
				for (int y = c.getY(); y <= c.getY() + 11; y++) {
					set(lv, c.getX() + dx, y, c.getZ() + dz, b(Blocks.AIR));
				}
			}
		}
	}

	private Rockets() {
	}
}
