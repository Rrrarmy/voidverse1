package com.voidverse;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Solar system ka layout + har planet ke blocks. Space dimension ke chunks yahan se fill hote hain. */
public final class Planets {
	public enum Kind { SUN, MERCURY, VENUS, EARTH, MOON, MARS, JUPITER, SATURN, URANUS, NEPTUNE }

	public record Planet(String name, Kind kind, int x, int y, int z, int radius, double gravity, int reach) {
		/** Planet ki surface se distance (negative = andar). */
		public double edgeDistance(double px, double py, double pz) {
			double dx = px - x, dy = py - y, dz = pz - z;
			return Math.sqrt(dx * dx + dy * dy + dz * dz) - radius;
		}
	}

	public static final int CENTER_Y = 128;
	public static final List<Planet> ALL = build();

	private static Planet orbit(String name, Kind kind, double dist, double deg, int r, double g) {
		int x = (int) Math.round(dist * Math.cos(Math.toRadians(deg)));
		int z = (int) Math.round(dist * Math.sin(Math.toRadians(deg)));
		return new Planet(name, kind, x, CENTER_Y, z, r, g, r);
	}

	private static List<Planet> build() {
		List<Planet> l = new ArrayList<>();
		l.add(new Planet("sun", Kind.SUN, 0, CENTER_Y, 0, 40, 0.5, 40));
		l.add(orbit("mercury", Kind.MERCURY, 110, 20, 6, 0.03));
		l.add(orbit("venus", Kind.VENUS, 170, 75, 10, 0.072));
		Planet earth = orbit("earth", Kind.EARTH, 260, 130, 12, 0.08);
		l.add(earth);
		l.add(new Planet("moon", Kind.MOON, earth.x() + 42, CENTER_Y, earth.z() + 10, 5, 0.013, 5));
		l.add(orbit("mars", Kind.MARS, 350, 200, 8, 0.03));
		l.add(orbit("jupiter", Kind.JUPITER, 500, 250, 30, 0.2));
		Planet sat = orbit("saturn", Kind.SATURN, 680, 310, 25, 0.085);
		l.add(new Planet(sat.name(), sat.kind(), sat.x(), sat.y(), sat.z(), sat.radius(), sat.gravity(), (int) (25 * 2.1) + 1));
		l.add(orbit("uranus", Kind.URANUS, 830, 40, 17, 0.07));
		l.add(orbit("neptune", Kind.NEPTUNE, 980, 100, 16, 0.09));
		return List.copyOf(l);
	}

	public static Planet byName(String name) {
		String n = name.toLowerCase(Locale.ROOT);
		for (Planet p : ALL) {
			if (p.name().equals(n)) return p;
		}
		return null;
	}

	// ---------- block palettes ----------
	private static final Block[] SUN_SURF = {Blocks.GLOWSTONE, Blocks.SHROOMLIGHT, Blocks.MAGMA_BLOCK, Blocks.ORANGE_CONCRETE};
	private static final Block[] MERC_SURF = {Blocks.STONE, Blocks.ANDESITE, Blocks.COBBLESTONE};
	private static final Block[] VENUS_SURF = {Blocks.SANDSTONE, Blocks.YELLOW_TERRACOTTA, Blocks.SMOOTH_SANDSTONE};
	private static final Block[] MARS_SURF = {Blocks.RED_TERRACOTTA, Blocks.ORANGE_TERRACOTTA, Blocks.RED_SANDSTONE};
	private static final Block[] MOON_SURF = {Blocks.LIGHT_GRAY_CONCRETE, Blocks.ANDESITE, Blocks.STONE};
	private static final Block[] JUPITER_BANDS = {Blocks.ORANGE_TERRACOTTA, Blocks.WHITE_TERRACOTTA, Blocks.BROWN_TERRACOTTA, Blocks.YELLOW_TERRACOTTA, Blocks.TERRACOTTA};
	private static final Block[] SATURN_BANDS = {Blocks.YELLOW_TERRACOTTA, Blocks.SANDSTONE, Blocks.TERRACOTTA, Blocks.SMOOTH_SANDSTONE};
	private static final Block[] URANUS_SURF = {Blocks.LIGHT_BLUE_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE, Blocks.CYAN_CONCRETE};
	private static final Block[] NEPTUNE_SURF = {Blocks.BLUE_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.BLUE_TERRACOTTA};

	private static BlockState pick(Block[] arr, int h) {
		return arr[h % arr.length].defaultBlockState();
	}

	private static BlockState s(Block b) {
		return b.defaultBlockState();
	}

	private static int hash(int x, int y, int z) {
		int h = x * 73856093 ^ y * 19349663 ^ z * 83492791;
		h ^= h >>> 13;
		h *= 0x5bd1e995;
		h ^= h >>> 15;
		return h & 0x7fffffff;
	}

	/** Is planet ka block (x,y,z) par; null = khali (air). */
	private static BlockState blockAt(Planet p, int x, int y, int z) {
		int dx = x - p.x(), dy = y - p.y(), dz = z - p.z();
		int r = p.radius();
		long d2 = (long) dx * dx + (long) dy * dy + (long) dz * dz;

		// Saturn ka ring
		if (p.kind() == Kind.SATURN && dy == 0 && d2 > (long) r * r) {
			double rd = Math.sqrt((double) dx * dx + (double) dz * dz);
			if (rd >= r * 1.45 && rd <= r * 2.1 && !(rd > r * 1.78 && rd < r * 1.84)) {
				return (((int) (rd / 2.0)) % 2 == 0) ? s(Blocks.WHITE_CONCRETE) : s(Blocks.LIGHT_GRAY_CONCRETE);
			}
			return null;
		}
		if (d2 > (long) r * r) return null;

		double dist = Math.sqrt(d2);
		double depth = r - dist;
		int h = hash(x, y, z);

		return switch (p.kind()) {
			case SUN -> depth < 4 ? pick(SUN_SURF, h) : (h % 2 == 0 ? s(Blocks.GLOWSTONE) : s(Blocks.SHROOMLIGHT));
			case MERCURY -> depth < 2 ? pick(MERC_SURF, h) : s(Blocks.STONE);
			case VENUS -> depth < 3 ? pick(VENUS_SURF, h) : s(Blocks.STONE);
			case MOON -> depth < 2 ? pick(MOON_SURF, h) : s(Blocks.STONE);
			case MARS -> depth < 3 ? pick(MARS_SURF, h) : s(Blocks.STONE);
			case JUPITER -> JUPITER_BANDS[Math.floorMod(Math.floorDiv(dy, 4), JUPITER_BANDS.length)].defaultBlockState();
			case SATURN -> SATURN_BANDS[Math.floorMod(Math.floorDiv(dy, 4), SATURN_BANDS.length)].defaultBlockState();
			case URANUS -> depth < 3 ? pick(URANUS_SURF, h) : s(Blocks.PACKED_ICE);
			case NEPTUNE -> depth < 3 ? pick(NEPTUNE_SURF, h) : s(Blocks.BLUE_ICE);
			case EARTH -> earthBlock(dx, dy, dz, dist, depth);
		};
	}

	private static BlockState earthBlock(int dx, int dy, int dz, double dist, double depth) {
		if (depth >= 4) return s(Blocks.STONE);
		double ux = dx / dist, uy = dy / dist, uz = dz / dist;
		double f = Math.sin(3 * ux + 1) * Math.sin(3 * uy + 2) * Math.sin(3 * uz + 3) + 0.6 * Math.sin(5 * uz + 4 * ux);
		boolean land = f > 0.05 || uy > 0.85; // north pole par hamesha zameen (landing site)
		if (depth < 1) return land ? s(Blocks.GRASS_BLOCK) : s(Blocks.BLUE_CONCRETE);
		if (land) return s(Blocks.DIRT);
		return depth < 2 ? s(Blocks.BLUE_CONCRETE) : s(Blocks.STONE);
	}

	/** Naya generate hua Space chunk planets se bhar do. */
	public static void fillChunk(LevelChunk chunk) {
		ChunkPos cp = chunk.getPos();
		int minX = cp.getMinBlockX();
		int minZ = cp.getMinBlockZ();
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

		for (Planet p : ALL) {
			int reach = p.reach();
			if (p.x() + reach < minX || p.x() - reach > minX + 15) continue;
			if (p.z() + reach < minZ || p.z() - reach > minZ + 15) continue;

			int x0 = Math.max(minX, p.x() - reach), x1 = Math.min(minX + 15, p.x() + reach);
			int z0 = Math.max(minZ, p.z() - reach), z1 = Math.min(minZ + 15, p.z() + reach);
			int y0 = Math.max(0, p.y() - reach), y1 = Math.min(255, p.y() + reach);

			for (int x = x0; x <= x1; x++) {
				for (int z = z0; z <= z1; z++) {
					for (int y = y0; y <= y1; y++) {
						BlockState st = blockAt(p, x, y, z);
						if (st != null) {
							chunk.setBlockState(pos.set(x, y, z), st, 0);
						}
					}
				}
			}
		}
	}

	private Planets() {
	}
}
