package com.voidverse;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public final class Dims {
	public static final String MOD_ID = "voidverse";

	/** Void ke niche ki duniya (villages wali). */
	public static final ResourceKey<Level> UNDERVERSE = key("underverse");
	/** Height limit ke upar ka universe (solar system). */
	public static final ResourceKey<Level> SPACE = key("space");

	private static ResourceKey<Level> key(String path) {
		return ResourceKey.create(Registries.DIMENSION, Identifier.fromNamespaceAndPath(MOD_ID, path));
	}

	private Dims() {
	}
}
