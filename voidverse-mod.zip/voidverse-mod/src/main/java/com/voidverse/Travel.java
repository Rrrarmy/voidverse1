package com.voidverse;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;
import java.util.Set;

/** Player ko Overworld / Underverse / Space ke planets ke beech bhejne ka kaam. */
public final class Travel {

	public static boolean to(ServerPlayer player, String dest) {
		MinecraftServer server = player.level().getServer();
		if (server == null) return false;
		dest = dest.toLowerCase(Locale.ROOT);

		if (dest.equals("overworld")) {
			ServerLevel ov = server.overworld();
			ov.getChunk(0, 0);
			int y = ov.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
			tp(player, ov, 0.5, y + 1, 0.5);
			return true;
		}

		if (dest.equals("underverse")) {
			ServerLevel ug = server.getLevel(Dims.UNDERVERSE);
			if (ug == null) return false;
			int x = (int) Math.floor(player.getX());
			int z = (int) Math.floor(player.getZ());
			try {
				// sabse paas ka village dhundho, taaki civilization ke upar hi landing ho
				BlockPos v = ug.findNearestMapStructure(StructureTags.VILLAGE, new BlockPos(x, 0, z), 32, false);
				if (v != null) {
					x = v.getX();
					z = v.getZ();
				}
			} catch (Exception ignored) {
				// village nahi mila to same x,z par hi
			}
			ug.getChunk(x >> 4, z >> 4);
			int y = ug.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
			tp(player, ug, x + 0.5, y + 40, z + 0.5);
			player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 900, 0));
			return true;
		}

		Planets.Planet pl = Planets.byName(dest);
		if (pl == null || pl.kind() == Planets.Kind.SUN) return false;
		ServerLevel sp = server.getLevel(Dims.SPACE);
		if (sp == null) return false;
		int cx = pl.x() >> 4, cz = pl.z() >> 4;
		for (int i = -2; i <= 2; i++) {
			for (int j = -2; j <= 2; j++) {
				sp.getChunk(cx + i, cz + j); // chunk generate -> planet ban jaata hai
			}
		}
		tp(player, sp, pl.x() + 0.5, pl.y() + pl.radius() + 1, pl.z() + 0.5);
		return true;
	}

	private static void tp(ServerPlayer p, ServerLevel level, double x, double y, double z) {
		p.teleportTo(level, x, y, z, Set.of(), p.getYRot(), p.getXRot(), true);
		p.setDeltaMovement(Vec3.ZERO);
		p.resetFallDistance();
	}

	private Travel() {
	}
}
